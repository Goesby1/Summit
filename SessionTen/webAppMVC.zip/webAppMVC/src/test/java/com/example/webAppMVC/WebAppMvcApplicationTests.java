package com.example.webAppMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebAppMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
