package com.example.webAppMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAppMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebAppMvcApplication.class, args);
	}

}
